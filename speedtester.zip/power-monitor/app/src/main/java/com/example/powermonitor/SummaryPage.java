package com.example.powermonitor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;

public class SummaryPage extends AppCompatActivity {

    TableLayout summary;
    Button handle;
    CardView Expandablecardview;
    private boolean isCollapsed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary_page);


        handle = (Button) findViewById(R.id.handle);
        summary = (TableLayout) findViewById(R.id.colladpsablesummary);
        summary.setVisibility(isCollapsed ? summary.GONE : summary.VISIBLE );

        handle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isCollapsed = !isCollapsed;
                View
            }
        });
    }
}
